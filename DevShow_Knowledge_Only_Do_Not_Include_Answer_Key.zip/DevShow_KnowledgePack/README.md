# Dev Show RAG Benchmark — The Meridian Incident

All names, systems, dates, events, and records in this pack are fictional and created for a retrieval demo.

## Purpose
Compare:
- Traditional vector RAG: retrieve top-k chunks and answer from retrieved text.
- LightRAG: entity/relation extraction, graph-based retrieval, and multi-hop evidence traversal.

This benchmark is intentionally designed so that a single chunk/document does not contain the complete answer to the hardest questions.

## Recommended ingestion
1. Ingest all files as one knowledge base.
2. Preserve filenames and timestamps where possible.
3. For Traditional RAG, start with chunk size 350–500 tokens, overlap 60–80 tokens, top-k 4–6.
4. For LightRAG, use the same source set. Allow entity/relation extraction to finish before querying.
5. Run each question in a fresh conversation. Do not include the answer key in the indexed knowledge base.

## Important fairness note
A strong LLM can sometimes infer answers from incomplete evidence. This is not proof that vector retrieval found the complete evidence. Evaluate retrieval separately from answer generation:
- Did the retrieved context contain every required fact?
- Did the answer cite the source for each link in the chain?
- Did it distinguish direct evidence from inference?
- Did it abstain when evidence was insufficient?

## Files
- `01_service_catalog.md`
- `02_chat_export_platform-team.md`
- `03_change_records.csv`
- `04_observability_fragments.txt`
- `05_identity_alias_registry.csv`
- `06_vendor_support_thread.md`
- `07_postmortem_appendix.md`
- `08_oncall_handover.md`
- `09_benchmark_questions.md`

`ANSWER_KEY_PRIVATE.md` is for the presenter only. Do not ingest it.

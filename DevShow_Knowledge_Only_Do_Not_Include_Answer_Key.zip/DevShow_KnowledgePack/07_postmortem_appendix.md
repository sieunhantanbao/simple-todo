# Postmortem appendix — INC-2041
Status: evidence appendix, not final blame assignment
Incident date: 2026-10-11

## Confirmed observations
- Cobalt primary `sql-pri-02` experienced severe write unavailability between approximately 00:31 and 02:10 UTC.
- The first sustained lock wait was on `shipments_current`.
- The SQL session label `shipment-projection-refresh` was associated with a transaction that remained open after an exception path.
- Atlas is the canonical service name for the workload deployed as `ord-projection-worker`.
- The Atlas consumer's reader contract was `shipment.v1` while the published writer contract had advanced to `shipment.v2`.

## Causality cautions
The postmortem team rejected two early claims:
1. “The person who approved CR-7714 caused the incident.” Approval is not execution.
2. “Mercury caused the database outage because it generated the most retries.” Mercury increased load during the incident, but the lock chain began before the retry rate was reduced and the database session trace points elsewhere.

The index maintenance operation may have increased sensitivity to the lock, but the available evidence does not establish it as the initiating transaction.

## Open evidence references
- `TRACE-ATLAS-6F2`: application trace for the projection refresh.
- `RUN-ATLAS-2026-1011-0027`: scheduled job metadata.
- `IDP-882`: identity provider subject from the release pipeline audit.
- `DBV-2048`: vendor analysis of the index maintenance lock behavior.

Do not assign individual fault based only on a service account, approver field, or session label.

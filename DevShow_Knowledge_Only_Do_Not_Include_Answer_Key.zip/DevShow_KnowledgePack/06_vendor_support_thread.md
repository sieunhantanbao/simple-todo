# Support thread: DB maintenance profile IDX-MAINT-B
Case: DBV-2048
Dates: 2026-10-11

[00:58 UTC] Support engineer: The profile's online index operation can request a schema-modification lock while it swaps the shadow index. Please provide the exact object and start time.

[01:17 UTC] Database Reliability: Target was `sql-pri-02`, object `shipments_current`. The operation began at 00:15 UTC under automation job `profile-apply-7715`.

[01:29 UTC] Support engineer: The lock duration in your telemetry is consistent with a swap phase waiting on a long-running transaction. It is not evidence that the index job itself held the lock continuously from 00:15.

[01:46 UTC] Database Reliability: We found the session label `shipment-projection-refresh` holding a transaction opened at 00:27 UTC. Need to map that label to its application principal before assigning ownership.

[02:12 UTC] Support engineer: Do not infer the human operator from the SQL session label. Correlate the session's client application name and trace ID with the application deployment and job metadata.

[03:04 UTC] Database Reliability: The transaction trace points to the scheduled projection refresh launched by Atlas. We are still checking why that refresh did not close its transaction after the reader decode exception.

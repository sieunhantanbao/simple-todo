# Benchmark questions

## Tier 1 — direct retrieval
1. What is the canonical name of the workload deployed as `checkout-edge`?
2. Which Kafka consumer group reads the `shipment-events` topic?
3. Which SQL node is the primary node for Cobalt?

## Tier 2 — cross-document entity resolution
4. Which human initiated the production publication of `shipment.v2`? Give the person's name and explain why the change approver is not the answer.
5. Which service is also known as `OrderMirror`, and what is its deployed workload name?
6. Which human approved the change that lowered Mercury's retry attempts, and what was the new value?

## Tier 3 — multi-hop causal reasoning
7. Reconstruct the chain that left the SQL transaction open during the incident. Your answer must connect the schema mismatch, consumer exception path, scheduled refresh run, and database session label.
8. Why did the registry's green compatibility result fail to prevent the Atlas consumer failure?
9. Did Mercury initiate the Cobalt outage? Separate initiating cause from aggravating factor and cite the timeline evidence.
10. Who should be attributed with initiating the `shipment.v2` production publication? Trace the service account to the human identity, and distinguish initiator, executor credential, and approver.

## Tier 4 — adversarial / abstention
11. Was Marco Silva responsible for the long-running transaction because he approved CR-7715? Answer only if the evidence supports personal execution.
12. Who last modified the `nightly-shipment-rollup` job definition? If the pack does not establish this, say so and identify what evidence would be needed.
13. Did the index maintenance profile definitely cause the outage? Explain what is known and what remains unproven.
14. Is `shipment-projection-refresh` a human, a service, a SQL session label, or a service account?
15. The database alert began at 00:31 UTC. Does that prove the index maintenance started the incident? Explain the difference between a preceding change and an initiating failure.

## Evaluation instruction
For questions 7–10, award full credit only when the answer cites evidence from at least three distinct files and preserves the causal distinctions. For questions 11–15, reward calibrated uncertainty; unsupported blame or invented identity is incorrect.

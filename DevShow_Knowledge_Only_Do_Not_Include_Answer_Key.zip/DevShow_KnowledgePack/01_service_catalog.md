# Service Catalog — Platform Operations
Revision: 2026-10-28

## Service identities
The customer checkout path is called **Mercury** in business dashboards. In Kubernetes it is deployed as `checkout-edge`. The internal service registry still lists its older name, `CartFront`. These three labels refer to the same workload, but not to the same repository.

The asynchronous order pipeline is called **Atlas** by the operations team. Its consumer deployment is `ord-projection-worker`; the Kafka group ID is `order-projection-v3`. Some older runbooks call this component `OrderMirror`.

The SQL database cluster is registered as **Cobalt**. Its primary node is `sql-pri-02`; the database name used by the billing service is `LedgerCore`. The BI team sometimes calls the same primary node “the midnight writer” because its maintenance window begins at 00:30.

## Ownership
- Mercury / `checkout-edge`: Checkout Experience team.
- Atlas / `ord-projection-worker`: Data Integration team.
- Cobalt / `sql-pri-02`: Database Reliability team.
- Schema Registry: Platform Foundations team.

## Operational conventions
Change records use the human approver's employee ID, not necessarily the person who executed a command.
Kubernetes audit records identify the service account that made an API call. A service account name is not proof of which human initiated the action.
Incident timelines use UTC unless a record explicitly says local time.

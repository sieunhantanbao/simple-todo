# On-call handover — Data Integration
Written 2026-10-11 06:30 UTC

The scheduled Atlas projection refresh is started by the `nightly-shipment-rollup` scheduler. Its job definition is maintained in the Data Integration repository.

The scheduler's runtime identity is `atlas-batch-prod`. The human who last changed the job definition is not necessarily the person who launched a particular run.

For run `RUN-ATLAS-2026-1011-0027`, the trace shows:
- deployment: `ord-projection-worker`
- consumer group: `order-projection-v3`
- transaction label: `shipment-projection-refresh`
- trace: `TRACE-ATLAS-6F2`

The exception handler logged the decode failure and marked the message as failed, but the transaction scope was disposed only on the success branch in the deployed build. This left the SQL transaction open while the refresh worker retried.

The job definition was last modified under commit `a91c7e2`. The Git hosting audit records the committer identity separately from the merge approver. The commit author field is not sufficient to establish who approved or deployed it.

A later hotfix added `finally`-based transaction disposal. The hotfix author is outside the scope of this incident attribution.

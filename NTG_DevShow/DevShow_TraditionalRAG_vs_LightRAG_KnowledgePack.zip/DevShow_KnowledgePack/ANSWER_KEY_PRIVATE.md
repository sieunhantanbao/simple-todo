# PRESENTER ONLY — Answer key
Do not ingest this file into the RAG knowledge base.

## Tier 1
1. Mercury (legacy alias CartFront).
2. `order-projection-v3`.
3. `sql-pri-02`.

## Tier 2
4. Anh Tran (EMP-552). `04_observability_fragments.txt` shows pipeline principal `svc-release-prod` and initiator_ref `IDP-882`; `05_identity_alias_registry.csv` maps IDP-882 to EMP-552 / anh.tran@corp.example. `03_change_records.csv` shows EMP-104 as approver, and chat says approver is not necessarily executor/initiator. The pipeline credential is the executor identity, not the human.
5. Atlas; deployed as `ord-projection-worker`.
6. Chen Wei (EMP-318) approved CR-7716; retry attempts changed from 12 to 4. The file records approver, not necessarily command executor.

## Tier 3
7. Writer contract advanced to `shipment.v2` while Atlas still used reader contract `shipment.v1` (chat + observability). The consumer could not decode `dispatchWindow`. During scheduled Atlas run RUN-ATLAS-2026-1011-0027, the exception path failed to dispose the SQL transaction (handover). That refresh held an open transaction under session label `shipment-projection-refresh` (vendor thread + postmortem), contributing to the long-running lock on `shipments_current` on `sql-pri-02` (observability). The index maintenance may have increased sensitivity but is not proven to be the initiating transaction.
8. The registry green check validated producer/writer compatibility only, not the old Atlas reader contract. Chat explicitly warns about this; service catalog gives ownership/context; observability confirms writer v2 vs reader v1 and decode failure.
9. No. Mercury retry amplification aggravated database load (observability; chat), but Atlas' transaction/session chain is the supported initiating mechanism. The lock wait began 00:31; Atlas decode failure logged 00:44, while support evidence indicates the refresh transaction opened 00:27. Be careful: the supplied evidence shows the refresh transaction existed before the Kafka decode log, but the exact causal ordering of exception and open transaction needs trace-level confirmation. A high-quality answer should say the handover states the exception path left the transaction open; Mercury is an aggravator, not the evidenced initiator.
10. Anh Tran / EMP-552 is the human initiator mapped from IDP-882. `svc-release-prod` is the pipeline principal/execution credential. EMP-104 / Priya Nair is the approver. These are three distinct roles.

## Tier 4
11. No. Marco Silva (EMP-209) approved CR-7715. The SQL job ran under `svc-dba-automation`; there is no evidence that Marco personally executed it or caused the transaction.
12. Not established. Need Git hosting audit for commit `a91c7e2`, plus scheduler/job-definition audit and deployment/run provenance. Commit author alone would not prove who last modified/merged/deployed.
13. No. Support says online index swap can request a schema-modification lock and may have increased sensitivity, but it does not establish the index job as the initiating transaction. The projection refresh transaction is separately implicated.
14. It is a SQL session label associated with the Atlas projection refresh, not a human, service account, or canonical service name.
15. No. A preceding maintenance change is temporal correlation, not proof of causation. The lock telemetry, session trace, and application transaction lifecycle are needed to establish the initiating failure.

## Dataset design notes
This pack intentionally includes:
- aliases and canonical names split across files;
- human identity -> identity-provider subject -> shared service credential mapping;
- approver vs initiator vs executor distinctions;
- schema writer/reader compatibility mismatch;
- temporal overlap and decoy causal explanations;
- session label vs service vs human distinctions;
- explicit unknowns that should trigger abstention.

One deliberate nuance: Question 7's strongest causal claim relies on combining the handover with the trace references in the postmortem and vendor thread. A production-grade benchmark should include the underlying trace export if you want to test attribution more rigorously.
